--------------------------------------------------
Synthetic asteroid models (a sample), instructions
--------------------------------------------------


This archive contains the following files:
* asteroideja.txt - a sample file demonstrating the expected syntax of the asteroid model listing
* damit_listaus.m - a MATLAB file you can use for creating the list file asteroideja.txt from your own custom models
* 3.txt - a sample asteroid model from DAMIT
* this readme


Installation instructions:
--------------------------

Extract asteroideja.txt and damit_listaus.m to your MATLAB work directory. The asteroid model files (e.g. the file 3.txt included on this archive) should be placed in the folder

[your MATLAB work directory]\Dimensiot\

The sample model 3.txt (a model of Juno) was created by Kaasalainen et al. (2002a) and Durech et al. (2011). You may use your own custom asteroid models, as long as they use the following syntax:

--- for each vertex ---
v vertex_x vertex_y vertex_z
--- for each face ---
f index_of_vertex_1 index_of_vertex_2 index_of_vertex_3

The rows starting with the character 'v' present a vertex, while the rows starting with 'f' present a face.

Additional asteroid models can be downloaded from DAMIT: http://astro.troja.mff.cuni.cz/projects/asteroids3D/web.php?page=db_browse

If you use DAMIT for your research, please cite Durech et al. (2010) as well as the original paper where the model was published, and give a link to the DAMIT website: http://astro.troja.mff.cuni.cz/projects/asteroids3D/web.php


Usage:
------

The synthetic simulator uses the files given in asteroideja.txt to create synthetic asteroid models. You may either manually edit the file asteroideja.txt by adding the paths to the files you want to use, or alternatively, you can copy all your asteroid model files to

[your MATLAB work directory]\Dimensiot\

and run the code damit_listaus.m to create (or update) the list file asteroideja.txt.

The synthetic simulator will apply basic transformations, such as stretching, on the asteroid models to fix the shape elongation on a desired value.


References:
-----------

Durech et al. (2010), DAMIT: a database of asteroid models, A&A, 513, A46
Durech et al. (2011), Combining asteroid models derived by lightcurve inversion with asteroidal occultation silhouettes, Icarus, 214, 652
Kaasalainen et al. (2002a), Models of twenty asteroids from photometric data, Icarus, 159, 369