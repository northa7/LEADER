--------------------------------------
WISE database (a sample), instructions
--------------------------------------


This archive contains the following files:
* lcg_files_WISE.mat - a MATLAB file required by the software package
* 4,331 .obs type data files from the WISE database
* this readme


Installation instructions:
--------------------------

Extract all of the files to your MATLAB work directory. For example, if your work directory is

C:\Users\[your_user_name]\Documents\MATLAB

extract the file 'lcg_files_WISE.mat' to that directory, and the .obs files should be located in the subdirectory WISE\WISE_3band\obs, for example:

C:\Users\[your_user_name]\Documents\MATLAB\WISE\WISE_3band\obs

The folder WISE\WISE_3band\obs should contain 4,331 .obs type text files. These are data files for various asteroids from the WISE database.


Usage:
------
The file 'lcg_files_WISE.mat' contains a MATLAB variable called 'lcg_files', which has a directory list to the WISE data files. To use this listing outside the software package, run the following command in MATLAB:

load lcg_files_WISE

This will load a 4331x1 cell file, where each component of the cell contains the path of an .obs data file.

The WISE data files use the following syntax in their formatting:

number of blocks (i.e. observations)

--- for each block ---
Julian_Date number_of_filters
Sun_x Sun_y Sun_z (asteroid-centric ecliptic)
Earth_X Earth_y Earth_z (asteroid-centric ecliptic)
--- for each filter/band ---
wavelength(um) flux(mJy) flux_error(mJy) filter_code

Possible filter codes and their corresponding wavelengths:
0	3.4 um
1	4.6 um
2	11 um
3	22 um


Acknowledgements:
-----------------

This publication makes use of data products from the Wide-field Infrared Survey Explorer, which is a joint project of the University of California, Los Angeles, and the Jet Propulsion Laboratory/California Institute of Technology, funded by the National Aeronautics and Space Administration. This publication also makes use of data products from NEOWISE, which is a project of the Jet Propulsion Laboratory/California Institute of Technology, funded by the Planetary Science Division of the National Aeronautics and Space Administration.

The data were checked against quality and reliability criteria described in Al�-Lagoa et al. (2016).

References:

Al�-Lagoa et al. 2016 A&A, 591, A14
Mainzer et al. 2011 ApJ, 731, 53
Wright et al. 2010 AJ, 140, 1868